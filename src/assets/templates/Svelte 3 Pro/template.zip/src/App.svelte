<script>
  export let name;
</script>

<h1>Hello {name}!</h1>
