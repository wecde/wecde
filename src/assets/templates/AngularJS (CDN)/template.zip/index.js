angular.module("app", []).controller("MainCtrl", ($scope) => {
  $scope.heading = "AngularJS";
  $scope.text =
    "Never attribute to malice what can be adequately explained by stupidity.";
});
