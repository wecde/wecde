import { Logger } from "./log";

Logger.log("TypeScript works!");
