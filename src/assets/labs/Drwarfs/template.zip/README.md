# Dwarfs: There and Back Again
**A basic idle game made wih JS. Won JS13K 2019 at 8th place and 2th place in mobile category.**
![dwarfs](screenshot.png)

## Installation
Install dependencies.
```
npm install
```

Build a compact version in both **build** and **electronapp** folders.
```
./build.sh
```

### Generating an Electron app
![dwarfs](screenshot2.png)
Enter to the **electronapp** folder.
```
cd electronapp
```

Install dependencies.
```
npm install
```

## Contributors

*Original Author: [Msvalikov](https://github.com/mvasilkov)*

*Contributor: [Yutyo](https://github.com/yutyo)*
