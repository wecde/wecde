new Vue({
  el: "#app",
  data: {
    heading: "Vue.js",
    text: "Happiness makes up in height what it lacks in length.",
  },
});
