console.log("hello world!");
let elem: HTMLElement | null;
if ((elem = document.getElementById("app"))) {
  elem.textContent = "Hello World App!";
}
